README: place your atp-shield-mark.png and atp-lockup.png here (transparent). Used by BrandLogo.
